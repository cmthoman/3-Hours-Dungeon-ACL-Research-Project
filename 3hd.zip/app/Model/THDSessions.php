<?php
class THDSessions extends AppModel{
	var $useDbConfig = 'shared';
    var $useTable = 'cake_sessions';
}
