<? class Search extends AppModel {
	 	
	 public $useTable = false; // This model does not use a database table
	 
}
?>