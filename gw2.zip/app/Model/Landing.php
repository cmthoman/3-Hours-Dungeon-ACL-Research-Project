<?php
class Landing extends AppModel {
	
	public $useTable = false;	
}
