<?php
class Action extends Model {
	public $actsAs = array('Acl' => array('type' => 'controlled'));
	
	public function parentNode() {
        if (!$this->id && empty($this->data)) {
            return null;
        }
        if (isset($this->data['Controller']['controller_id'])) {
            $controllerId = $this->data['Controller']['controller_id'];
        } else {
            $controllerId = $this->field('controller_id');
        }
        if (!$controllerId) {
            return null;
        } else {
            return array('Group' => array('id' => $controllerId));
        }
    }
		
	public $belongsTo = array(
		'Controller'
	);
}