<?php
class LogUser extends AppModel{
	
}
