<?php
class THDSessions extends AppModel{
	
}
