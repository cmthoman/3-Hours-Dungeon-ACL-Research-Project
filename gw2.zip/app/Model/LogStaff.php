<?php
class LogStaff extends AppModel{
	
}
