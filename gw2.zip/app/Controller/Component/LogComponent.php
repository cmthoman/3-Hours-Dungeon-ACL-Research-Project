<?php
class LogComponent extends Component{
	
	function user($id, $action){
		$log['UserLog']['id'] = $id;
		$log['UserLog']['controller'] = $controller;
		$log['UserLog']['action'] = $action;
		$this->LogUser->save($log);
	}
	
	function staff(){
		
	}
}
