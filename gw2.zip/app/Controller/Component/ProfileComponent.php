<?php
Class ProfileComponent extends Component{
		
	public function check($id){
		
	}
}
