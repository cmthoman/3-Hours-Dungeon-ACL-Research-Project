<?php
App::uses('Component', 'Controller');
class emailsComponent extends Component {
	
	public function sendAuthEmail(){
		$email = new CakeEmail();
		$email->emailFormat('text');
		$email->template('activation', 'activation');
		$email->from(array('noreply@3hoursdungeon.com' => '3 Hours Dungeon'));
		$email->to($this->data['User']['email']);
		$email->subject('3 Hours Dungeon Account Activation');
		$email->send();
	}
}
