<?php
Class UserProfileController extends AppController {
	
	function editGroup($id = null){
		$this->UserProfile->id = $id;
		if($this->request->is('get')){
			$this->request->data = $this->UserProfile->read();
		}else{
			$this->UserProfile->save($this->request->data);
		}
	}
}
